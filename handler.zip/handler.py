"""
Lambda — Snowflake connectivity test using RSA key-pair authentication.

Connects to Snowflake using a PEM private key stored in Secrets Manager.
Runs a simple query to verify connectivity and returns the result.

Environment variables:
  SECRET_NAME  — Secrets Manager secret containing the PEM private key
  SF_ACCOUNT   — Snowflake account identifier (e.g. "xy12345.us-east-1")
  SF_USER      — Snowflake username
  SF_WAREHOUSE — Snowflake warehouse (optional, default: "ETL_WH")
  SF_DATABASE  — Snowflake database (optional)
  SF_SCHEMA    — Snowflake schema (optional, default: "PUBLIC")
  SF_ROLE      — Snowflake role (optional)

Secrets Manager JSON format:
  { "private_key_pem": "-----BEGIN ENCRYPTED PRIVATE KEY-----\\n..." }
  OR just the raw PEM string directly.
"""

import os
import json
import boto3
from cryptography.hazmat.primitives import serialization
from cryptography.hazmat.backends import default_backend
import snowflake.connector

SECRET_NAME = os.environ["SECRET_NAME"]
SF_ACCOUNT = os.environ["SF_ACCOUNT"]
SF_USER = os.environ["SF_USER"]
SF_WAREHOUSE = os.environ.get("SF_WAREHOUSE", "ETL_WH")
SF_DATABASE = os.environ.get("SF_DATABASE", "")
SF_SCHEMA = os.environ.get("SF_SCHEMA", "PUBLIC")
SF_ROLE = os.environ.get("SF_ROLE", "")

secrets_client = boto3.client("secretsmanager")


def get_private_key():
    """
    Fetch PEM private key from Secrets Manager and decode it.
    Supports both JSON format {"private_key_pem": "..."} and raw PEM string.
    """
    response = secrets_client.get_secret_value(SecretId=SECRET_NAME)
    secret_value = response["SecretString"]

    # Try JSON format first
    try:
        parsed = json.loads(secret_value)
        pem_data = parsed.get("private_key_pem", parsed.get("privateKey", ""))
    except (json.JSONDecodeError, TypeError):
        # Raw PEM string
        pem_data = secret_value

    if not pem_data:
        raise ValueError("No private key found in secret")

    # Handle escaped newlines from JSON storage
    pem_data = pem_data.replace("\\n", "\n")

    # Load the private key (supports both encrypted and unencrypted PEM)
    pem_bytes = pem_data.encode("utf-8")
    try:
        # Try without passphrase first (unencrypted key)
        private_key = serialization.load_pem_private_key(
            pem_bytes, password=None, backend=default_backend()
        )
    except (ValueError, TypeError):
        # If that fails, the key might need a passphrase from env
        passphrase = os.environ.get("SF_KEY_PASSPHRASE", "").encode("utf-8") or None
        private_key = serialization.load_pem_private_key(
            pem_bytes, password=passphrase, backend=default_backend()
        )

    # Convert to DER format (what snowflake-connector expects)
    pkb = private_key.private_bytes(
        encoding=serialization.Encoding.DER,
        format=serialization.PrivateFormat.PKCS8,
        encryption_algorithm=serialization.NoEncryption(),
    )
    return pkb


def handler(event, context):
    """Lambda entry point — test Snowflake connectivity via RSA key-pair."""
    print(f"Connecting to Snowflake: account={SF_ACCOUNT}, user={SF_USER}")
    print(f"Warehouse={SF_WAREHOUSE}, Database={SF_DATABASE}, Schema={SF_SCHEMA}")

    # Get private key from Secrets Manager
    private_key_der = get_private_key()
    print("Private key loaded from Secrets Manager")

    # Connect using key-pair auth
    conn_params = {
        "account": SF_ACCOUNT,
        "user": SF_USER,
        "private_key": private_key_der,
        "warehouse": SF_WAREHOUSE or None,
        "schema": SF_SCHEMA or None,
        "role": SF_ROLE or None,
    }
    if SF_DATABASE:
        conn_params["database"] = SF_DATABASE

    conn = snowflake.connector.connect(**conn_params)
    cursor = conn.cursor()

    try:
        # Test query
        test_query = event.get("query", "SELECT CURRENT_TIMESTAMP(), CURRENT_USER(), CURRENT_ROLE()")
        print(f"Executing: {test_query}")

        cursor.execute(test_query)
        columns = [desc[0] for desc in cursor.description]
        rows = cursor.fetchall()

        print(f"Success — {len(rows)} rows returned")
        print(f"Columns: {columns}")
        for row in rows[:5]:
            print(f"  {row}")

        return {
            "statusCode": 200,
            "status": "connected",
            "account": SF_ACCOUNT,
            "user": SF_USER,
            "columns": columns,
            "rows": [list(row) for row in rows[:10]],
            "rowCount": len(rows),
        }

    except Exception as e:
        print(f"Query failed: {e}")
        return {
            "statusCode": 500,
            "status": "error",
            "error": str(e),
        }
    finally:
        cursor.close()
        conn.close()
